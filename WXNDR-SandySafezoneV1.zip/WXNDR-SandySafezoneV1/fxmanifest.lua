------ CFX / FIVEM RESOURCE VARIBLES ------

fx_version "cerulean"
games { 'gta5' }

author 'Wxndr'
description 'Sandy Shores Zombie Survival Safezone'
version '1.0.0'

------ MAP VARIBLES ------

this_is_a_map 'yes'

------ PRODUCT INFORMATION ------

-- This map is made from Base GTA V Objects, this is not an MLO and will never be. --
-- Updates will be made from time to time adding new details and additional places for vendors and areas around. --
-- If you encounter any issues, please feel free to add me on Discord and send me a PM, or leave a message on the original topic --

------ TERMS OF SERVICE ------

-- You are NOT allowed to re-upload, re-distribute or advertise this as your own creation, revisions are allowed and will be merged if deemed good!
-- Please leave the file name the same (obviously if need-be you're able to compress this into other maps)

